#!/bin/bash

source environment.sh

PYTHON_BIN=python3

echo "ReCreating Python environment..."
${PYTHON_BIN} -m venv ${Directory_PythonEnv}

echo "Activating the Python environment..."
${Directory_PythonEnv}/bin/pip install Flask
